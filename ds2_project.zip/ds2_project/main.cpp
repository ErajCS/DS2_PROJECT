//not printing rb tree and s u d matrices 

// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <map>
// #include <Eigen>
// #include <tuple>
// #include <algorithm>

// using namespace std;
// using namespace Eigen;

// // Helper function to split CSV rows
// vector<string> split(const string& s, char delimiter) {
//     vector<string> tokens;
//     string token;
//     istringstream tokenStream(s);
//     while (getline(tokenStream, token, delimiter)) {
//         tokens.push_back(token);
//     }
//     return tokens;
// }

// // Helper function to safely convert a string to a float
// float safe_stof(const string& str) {
//     try {
//         return stof(str);
//     } catch (const invalid_argument& e) {
//         cerr << "Invalid rating value: " << str << endl;
//         return 0.0f;
//     }
// }

// int main() {
//     ifstream file("movies_smalldata.csv");
//     string line;

//     if (!file.is_open()) {
//         cerr << "Failed to open the file!" << endl;
//         return -1;
//     }

//     map<int, int> userIndexMap, movieIndexMap;
//     map<int, string> movieNameMap;
//     vector<tuple<int, int, float>> ratings;
    
//     int userCount = 0, movieCount = 0;

//     getline(file, line);  // Skip header
    
//     while (getline(file, line)) {
//         vector<string> tokens = split(line, ',');
//         if (tokens.size() < 4) continue;
        
//         int user = stoi(tokens[0]);
//         int movie = stoi(tokens[1]);
//         string movieName = tokens[2];
//         float rating = safe_stof(tokens[3]);
        
//         cout << "Parsed line: " << user << ", " << movie << ", " << movieName << ", " << rating << endl;
        
//         if (userIndexMap.find(user) == userIndexMap.end())
//             userIndexMap[user] = userCount++;
//         if (movieIndexMap.find(movie) == movieIndexMap.end()) {
//             movieIndexMap[movie] = movieCount++;
//             movieNameMap[movie] = movieName;
//         }
        
//         ratings.push_back({user, movie, rating});
//     }

//     MatrixXf ratingMatrix = MatrixXf::Zero(userCount, movieCount);
//     for (auto& r : ratings) {
//         int userIdx = userIndexMap[get<0>(r)];
//         int movieIdx = movieIndexMap[get<1>(r)];
//         ratingMatrix(userIdx, movieIdx) = get<2>(r);
//     }

//     cout << "Number of users: " << userCount << ", Number of movies: " << movieCount << endl;
//     cout << "Matrix dimensions: " << ratingMatrix.rows() << " x " << ratingMatrix.cols() << endl;
//     cout << "Rating Matrix: \n" << ratingMatrix << endl;

//     if (ratingMatrix.rows() == 0 || ratingMatrix.cols() == 0) {
//         cerr << "Error: The rating matrix is empty!" << endl;
//         return -1;
//     }

//     JacobiSVD<MatrixXf> svd(ratingMatrix, ComputeThinU | ComputeThinV);
//     MatrixXf U = svd.matrixU();
//     MatrixXf S = svd.singularValues().asDiagonal();
//     MatrixXf V = svd.matrixV();

//     MatrixXf predictedRatings = U * S * V.transpose();

//     int targetUser = 1114;
//     if (userIndexMap.find(targetUser) == userIndexMap.end()) {
//         cout << "User " << targetUser << " not found in dataset!" << endl;
//         return 0;
//     }

//     int userIdx = userIndexMap[targetUser];
//     vector<pair<int, float>> recommendations;

//     for (auto& moviePair : movieIndexMap) {
//         int movieId = moviePair.first;
//         int movieIdx = moviePair.second;

//         if (ratingMatrix(userIdx, movieIdx) == 0) {
//             float predictedRating = predictedRatings(userIdx, movieIdx);
//             recommendations.push_back({movieId, predictedRating});
//         }
//     }

//     sort(recommendations.begin(), recommendations.end(), [](const pair<int, float>& a, const pair<int, float>& b) {
//         return a.second > b.second;
//     });

//     cout << "\nTop recommended movies for User " << targetUser << ":\n";
//     for (int i = 0; i < min(5, (int)recommendations.size()); i++) {
//         cout << movieNameMap[recommendations[i].first] << " - Predicted Rating: " << recommendations[i].second << endl;
//     }

//     return 0;
// }

//not printing rb tree 
 
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <tuple>
// #include <algorithm>
// #include <Eigen>

// using namespace std;
// using namespace Eigen;

// // Basic Red-Black Tree node
// template<typename K, typename V>
// struct RBNode {
//     K key;
//     V value;
//     bool red;
//     RBNode *left, *right, *parent;

//     RBNode(K k, V v) : key(k), value(v), red(true), left(nullptr), right(nullptr), parent(nullptr) {}
// };

// // Red-Black Tree implementation (partial, insert + find)
// template<typename K, typename V>
// class RBTree {
//     RBNode<K, V>* root;

//     void leftRotate(RBNode<K, V>* x) {
//         RBNode<K, V>* y = x->right;
//         x->right = y->left;
//         if (y->left) y->left->parent = x;
//         y->parent = x->parent;
//         if (!x->parent) root = y;
//         else if (x == x->parent->left) x->parent->left = y;
//         else x->parent->right = y;
//         y->left = x;
//         x->parent = y;
//     }

//     void rightRotate(RBNode<K, V>* x) {
//         RBNode<K, V>* y = x->left;
//         x->left = y->right;
//         if (y->right) y->right->parent = x;
//         y->parent = x->parent;
//         if (!x->parent) root = y;
//         else if (x == x->parent->right) x->parent->right = y;
//         else x->parent->left = y;
//         y->right = x;
//         x->parent = y;
//     }

//     void fixInsert(RBNode<K, V>* node) {
//         while (node->parent && node->parent->red) {
//             RBNode<K, V>* grandparent = node->parent->parent;
//             if (node->parent == grandparent->left) {
//                 RBNode<K, V>* uncle = grandparent->right;
//                 if (uncle && uncle->red) {
//                     node->parent->red = false;
//                     uncle->red = false;
//                     grandparent->red = true;
//                     node = grandparent;
//                 } else {
//                     if (node == node->parent->right) {
//                         node = node->parent;
//                         leftRotate(node);
//                     }
//                     node->parent->red = false;
//                     grandparent->red = true;
//                     rightRotate(grandparent);
//                 }
//             } else {
//                 RBNode<K, V>* uncle = grandparent->left;
//                 if (uncle && uncle->red) {
//                     node->parent->red = false;
//                     uncle->red = false;
//                     grandparent->red = true;
//                     node = grandparent;
//                 } else {
//                     if (node == node->parent->left) {
//                         node = node->parent;
//                         rightRotate(node);
//                     }
//                     node->parent->red = false;
//                     grandparent->red = true;
//                     leftRotate(grandparent);
//                 }
//             }
//         }
//         root->red = false;
//     }

// public:
//     RBTree() : root(nullptr) {}

//     void insert(K key, V value) {
//         RBNode<K, V>* z = new RBNode<K, V>(key, value);
//         RBNode<K, V>* y = nullptr;
//         RBNode<K, V>* x = root;

//         while (x) {
//             y = x;
//             if (key < x->key) x = x->left;
//             else if (key > x->key) x = x->right;
//             else return; // key already exists
//         }

//         z->parent = y;
//         if (!y) root = z;
//         else if (key < y->key) y->left = z;
//         else y->right = z;

//         fixInsert(z);
//     }

//     bool find(K key, V& value) {
//         RBNode<K, V>* current = root;
//         while (current) {
//             if (key == current->key) {
//                 value = current->value;
//                 return true;
//             } else if (key < current->key) current = current->left;
//             else current = current->right;
//         }
//         return false;
//     }

//     bool contains(K key) {
//         V dummy;
//         return find(key, dummy);
//     }

//     V get(K key) {
//         V value;
//         if (find(key, value)) return value;
//         throw runtime_error("Key not found");
//     }

//     vector<K> keys() {
//         vector<K> result;
//         inOrder(root, result);
//         return result;
//     }

// private:
//     void inOrder(RBNode<K, V>* node, vector<K>& result) {
//         if (!node) return;
//         inOrder(node->left, result);
//         result.push_back(node->key);
//         inOrder(node->right, result);
//     }
// };

// // Helper function to split CSV rows
// vector<string> split(const string& s, char delimiter) {
//     vector<string> tokens;
//     string token;
//     istringstream tokenStream(s);
//     while (getline(tokenStream, token, delimiter)) {
//         tokens.push_back(token);
//     }
//     return tokens;
// }

// float safe_stof(const string& str) {
//     try {
//         return stof(str);
//     } catch (...) {
//         cerr << "Invalid rating: " << str << endl;
//         return 0.0f;
//     }
// }

// int main() {
//     ifstream file("movies_smalldata.csv");
//     string line;

//     if (!file.is_open()) {
//         cerr << "Failed to open file.\n";
//         return -1;
//     }

//     RBTree<int, int> userIndexMap, movieIndexMap;
//     RBTree<int, string> movieNameMap;
//     vector<tuple<int, int, float>> ratings;

//     int userCount = 0, movieCount = 0;

//     getline(file, line); // Skip header

//     while (getline(file, line)) {
//         vector<string> tokens = split(line, ',');
//         if (tokens.size() < 4) continue;

//         int user = stoi(tokens[0]);
//         int movie = stoi(tokens[1]);
//         string movieName = tokens[2];
//         float rating = safe_stof(tokens[3]);

//         cout << "Parsed line: " << user << ", " << movie << ", " << movieName << ", " << rating << endl;

//         if (!userIndexMap.contains(user)) userIndexMap.insert(user, userCount++);
//         if (!movieIndexMap.contains(movie)) {
//             movieIndexMap.insert(movie, movieCount++);
//             movieNameMap.insert(movie, movieName);
//         }

//         ratings.push_back({user, movie, rating});
//     }

//     MatrixXf ratingMatrix = MatrixXf::Zero(userCount, movieCount);
//     for (auto& r : ratings) {
//         int userIdx = userIndexMap.get(get<0>(r));
//         int movieIdx = movieIndexMap.get(get<1>(r));
//         ratingMatrix(userIdx, movieIdx) = get<2>(r);
//     }

//     cout << "\nRating Matrix:\n" << ratingMatrix << endl;

//     JacobiSVD<MatrixXf> svd(ratingMatrix, ComputeThinU | ComputeThinV);
//     MatrixXf U = svd.matrixU();
//     MatrixXf S = svd.singularValues().asDiagonal();
//     MatrixXf V = svd.matrixV();

//     //svd matrice sseparately output 
//     cout << "\n=== SVD Matrices ===" << endl;
//     cout << "Matrix U (Users x Latent Features):\n" << U << endl;
//     cout << "\nMatrix S (Singular Values as Diagonal Matrix):\n" << S << endl;
//     cout << "\nMatrix V (Movies x Latent Features):\n" << V << endl;

//     MatrixXf predictedRatings = U * S * V.transpose();

//     int targetUser = 1114;
//     if (!userIndexMap.contains(targetUser)) {
//         cout << "User not found.\n";
//         return 0;
//     }

//     int userIdx = userIndexMap.get(targetUser);
//     vector<pair<int, float>> recommendations;

//     for (int movieId : movieIndexMap.keys()) {
//         int movieIdx = movieIndexMap.get(movieId);
//         if (ratingMatrix(userIdx, movieIdx) == 0) {
//             float predictedRating = predictedRatings(userIdx, movieIdx);
//             recommendations.push_back({movieId, predictedRating});
//         }
//     }

//     sort(recommendations.begin(), recommendations.end(), [](auto& a, auto& b) {
//         return a.second > b.second;
//     });

//     cout << "\nTop recommendations for user " << targetUser << ":\n";
//     for (int i = 0; i < min(5, (int)recommendations.size()); i++) {
//         cout << movieNameMap.get(recommendations[i].first) << " - Predicted Rating: " << recommendations[i].second << endl;
//     }

//     return 0;
// }

//printing rb tree, S U D matrices and rating matrix 

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <tuple>
#include <algorithm>
#include <Eigen>

using namespace std;
using namespace Eigen;

// Basic Red-Black Tree node
template<typename K, typename V>
struct RBNode {
    K key;
    V value;
    bool red;
    RBNode *left, *right, *parent;

    RBNode(K k, V v) : key(k), value(v), red(true), left(nullptr), right(nullptr), parent(nullptr) {}
};

// Red-Black Tree implementation (partial, insert + find)
template<typename K, typename V>
class RBTree {
    RBNode<K, V>* root;

    void leftRotate(RBNode<K, V>* x) {
        RBNode<K, V>* y = x->right;
        x->right = y->left;
        if (y->left) y->left->parent = x;
        y->parent = x->parent;
        if (!x->parent) root = y;
        else if (x == x->parent->left) x->parent->left = y;
        else x->parent->right = y;
        y->left = x;
        x->parent = y;
    }

    void rightRotate(RBNode<K, V>* x) {
        RBNode<K, V>* y = x->left;
        x->left = y->right;
        if (y->right) y->right->parent = x;
        y->parent = x->parent;
        if (!x->parent) root = y;
        else if (x == x->parent->right) x->parent->right = y;
        else x->parent->left = y;
        y->right = x;
        x->parent = y;
    }

    void fixInsert(RBNode<K, V>* node) {
        while (node->parent && node->parent->red) {
            RBNode<K, V>* grandparent = node->parent->parent;
            if (node->parent == grandparent->left) {
                RBNode<K, V>* uncle = grandparent->right;
                if (uncle && uncle->red) {
                    node->parent->red = false;
                    uncle->red = false;
                    grandparent->red = true;
                    node = grandparent;
                } else {
                    if (node == node->parent->right) {
                        node = node->parent;
                        leftRotate(node);
                    }
                    node->parent->red = false;
                    grandparent->red = true;
                    rightRotate(grandparent);
                }
            } else {
                RBNode<K, V>* uncle = grandparent->left;
                if (uncle && uncle->red) {
                    node->parent->red = false;
                    uncle->red = false;
                    grandparent->red = true;
                    node = grandparent;
                } else {
                    if (node == node->parent->left) {
                        node = node->parent;
                        rightRotate(node);
                    }
                    node->parent->red = false;
                    grandparent->red = true;
                    leftRotate(grandparent);
                }
            }
        }
        root->red = false;
    }

public:
    RBTree() : root(nullptr) {}

    void insert(K key, V value) {
        RBNode<K, V>* z = new RBNode<K, V>(key, value);
        RBNode<K, V>* y = nullptr;
        RBNode<K, V>* x = root;

        while (x) {
            y = x;
            if (key < x->key) x = x->left;
            else if (key > x->key) x = x->right;
            else return; // key already exists
        }

        z->parent = y;
        if (!y) root = z;
        else if (key < y->key) y->left = z;
        else y->right = z;

        fixInsert(z);
    }

    bool find(K key, V& value) {
        RBNode<K, V>* current = root;
        while (current) {
            if (key == current->key) {
                value = current->value;
                return true;
            } else if (key < current->key) current = current->left;
            else current = current->right;
        }
        return false;
    }

    bool contains(K key) {
        V dummy;
        return find(key, dummy);
    }

    V get(K key) {
        V value;
        if (find(key, value)) return value;
        throw runtime_error("Key not found");
    }

    vector<K> keys() {
        vector<K> result;
        inOrder(root, result);
        return result;
    }

    // Printing function to display the tree structure
    void printTree() {
        printTree(root);
    }

private:
    void inOrder(RBNode<K, V>* node, vector<K>& result) {
        if (!node) return;
        inOrder(node->left, result);
        result.push_back(node->key);
        inOrder(node->right, result);
    }

    void printTree(RBNode<K, V>* node) {
        if (!node) return;
        cout << "Node Key: " << node->key 
             << ", Value: " << node->value 
             << ", Color: " << (node->red ? "Red" : "Black") 
             << ", Parent: " << (node->parent ? to_string(node->parent->key) : "None")
             << ", Left: " << (node->left ? to_string(node->left->key) : "None")
             << ", Right: " << (node->right ? to_string(node->right->key) : "None")
             << endl;
        printTree(node->left);
        printTree(node->right);
    }
};

// Helper function to split CSV rows
vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

float safe_stof(const string& str) {
    try {
        return stof(str);
    } catch (...) {
        cerr << "Invalid rating: " << str << endl;
        return 0.0f;
    }
}

int main() {
    ifstream file("movies_smalldata.csv");
    string line;

    if (!file.is_open()) {
        cerr << "Failed to open file.\n";
        return -1;
    }

    RBTree<int, int> userIndexMap, movieIndexMap;
    RBTree<int, string> movieNameMap;
    vector<tuple<int, int, float>> ratings;

    int userCount = 0, movieCount = 0;

    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> tokens = split(line, ',');
        if (tokens.size() < 4) continue;

        int user = stoi(tokens[0]);
        int movie = stoi(tokens[1]);
        string movieName = tokens[2];
        float rating = safe_stof(tokens[3]);

        cout << "Parsed line: " << user << ", " << movie << ", " << movieName << ", " << rating << endl;

        if (!userIndexMap.contains(user)) userIndexMap.insert(user, userCount++);
        if (!movieIndexMap.contains(movie)) {
            movieIndexMap.insert(movie, movieCount++);
            movieNameMap.insert(movie, movieName);
        }

        ratings.push_back({user, movie, rating});
    }

    MatrixXf ratingMatrix = MatrixXf::Zero(userCount, movieCount);
    for (auto& r : ratings) {
        int userIdx = userIndexMap.get(get<0>(r));
        int movieIdx = movieIndexMap.get(get<1>(r));
        ratingMatrix(userIdx, movieIdx) = get<2>(r);
    }

    cout << "\nRating Matrix:\n" << ratingMatrix << endl;

    JacobiSVD<MatrixXf> svd(ratingMatrix, ComputeThinU | ComputeThinV);
    MatrixXf U = svd.matrixU();
    MatrixXf S = svd.singularValues().asDiagonal();
    MatrixXf V = svd.matrixV();

    //svd matrice separately output 
    cout << "\n=== SVD Matrices ===" << endl;
    cout << "Matrix U (Users x Latent Features):\n" << U << endl;
    cout << "\nMatrix S (Singular Values as Diagonal Matrix):\n" << S << endl;
    cout << "\nMatrix V (Movies x Latent Features):\n" << V << endl;

    MatrixXf predictedRatings = U * S * V.transpose();

    int targetUser = 1114;
    if (!userIndexMap.contains(targetUser)) {
        cout << "User not found.\n";
        return 0;
    }

    int userIdx = userIndexMap.get(targetUser);
    vector<pair<int, float>> recommendations;

    for (int movieId : movieIndexMap.keys()) {
        int movieIdx = movieIndexMap.get(movieId);
        if (ratingMatrix(userIdx, movieIdx) == 0) {
            float predictedRating = predictedRatings(userIdx, movieIdx);
            recommendations.push_back({movieId, predictedRating});
        }
    }

    sort(recommendations.begin(), recommendations.end(), [](auto& a, auto& b) {
        return a.second > b.second;
    });

    cout << "\nTop recommendations for user " << targetUser << ":\n";
    for (int i = 0; i < min(5, (int)recommendations.size()); i++) {
        cout << movieNameMap.get(recommendations[i].first) << " - Predicted Rating: " << recommendations[i].second << endl;
    }

    // Print Red-Black Tree structure after insertion
    cout << "\nRed-Black Tree Structure:" << endl;
    userIndexMap.printTree();  // Print the user index map tree
    movieIndexMap.printTree(); // Print the movie index map tree
    movieNameMap.printTree();  // Print the movie name map tree

    return 0;
}

